import React, { useState } from 'react';
import UserService from '../service/UserService';

const RegisterPage = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [verificationCode, setVerificationCode] = useState('');
    const [message, setMessage] = useState('');
    const [isCodeSent, setIsCodeSent] = useState(false); // Kiểm tra xem mã đã được gửi hay chưa

    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            const response = await UserService.register({ username, email, password });
            setIsCodeSent(true); // Đánh dấu là mã đã được gửi
            setMessage('Registration successful! Please check your email for the verification code.');
        } catch (err) {
            setMessage(err.message);
        }
    };

    const handleVerifyCode = async (e) => {
        e.preventDefault();
        if (verificationCode.trim() === '') {
            setMessage('Please enter the verification code.');
            return;
        }

        try {
            // Gọi hàm verifyCode từ UserService
            const verificationResponse = await UserService.verifyCode(email, verificationCode);
            setMessage('Verification successful! You can now log in.');
            // Tiến hành đăng nhập hoặc chuyển hướng đến trang khác
        } catch (err) {
            setMessage(err.message);
        }
    };

    return (
        <div>
            <h2>Register</h2>
            <form onSubmit={handleRegister}>
                <div>
                    <label>Username:</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Register</button>
            </form>

            {isCodeSent && (
                <form onSubmit={handleVerifyCode}>
                    <h3>Verify Your Account</h3>
                    <div>
                        <label>Verification Code:</label>
                        <input
                            type="text"
                            value={verificationCode}
                            onChange={(e) => setVerificationCode(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit">Verify Code</button>
                </form>
            )}

            {message && <p>{message}</p>}
        </div>
    );
};

export default RegisterPage;
