import React, { useState } from 'react';
import UserService from '../service/UserService';
import { useNavigate } from 'react-router-dom';
import '../css/ForgotPassword.css';

function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [code, setCode] = useState('');
    const [message, setMessage] = useState('');
    const [isCodeSent, setIsCodeSent] = useState(false); // State mới để kiểm soát việc gửi mã
    const navigate = useNavigate();

    const handleForgotPassword = async (e) => {
        e.preventDefault();
        try {
            const response = await UserService.forgotPassword(email);
            setMessage(response.message || 'Verification code sent to your email.');
            setIsCodeSent(true); // Cập nhật trạng thái khi mã xác thực đã được gửi
        } catch (error) {
            setMessage(error.message);
        }
    };

    const handleVerifyCode = async (e) => {
        e.preventDefault();
        try {
            const trimmedCode = code.trim(); // Loại bỏ khoảng trắng
            const response = await UserService.verifyCode(email, trimmedCode);
            
            console.log('Verify Code Response:', response); // In ra phản hồi từ server
    
            // Kiểm tra phản hồi từ server
            if (response && response.status === 'success') {
                navigate('/reset-password', { state: { code: trimmedCode } });
            } else {
                setMessage('Invalid verification code. Please try again.');
            }
        } catch (error) {
            setMessage(error.message); // Thông báo lỗi nếu có
        }
    };

    return (
        <div className="forgot-password-container">
            <h2>Forgot Password</h2>
            {/* Form Nhập Email */}
            <form onSubmit={handleForgotPassword}>
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                />
                <button type="submit">Send Verification Code</button>
            </form>
            
            {/* Hiển thị ô nhập mã xác thực nếu mã đã được gửi thành công */}
            {isCodeSent && (
                <form onSubmit={handleVerifyCode} style={{ marginTop: '20px' }}>
                    <input
                        type="text"
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        placeholder="Enter verification code"
                        required
                    />
                    <button type="submit">Verify Code</button>
                </form>
            )}

            {message && <p>{message}</p>}
        </div>
    );
}

export default ForgotPassword;
