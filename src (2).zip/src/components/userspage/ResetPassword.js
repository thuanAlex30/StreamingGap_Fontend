import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import UserService from '../service/UserService';

function ResetPassword() {
    const [newPassword, setNewPassword] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate();
    const location = useLocation();

    // Lấy mã xác thực từ `location.state`
    const code = location.state?.code;

    const handleResetPassword = async (e) => {
        e.preventDefault();
        try {
            if (!code) throw new Error('Verification code missing.');
            
            const response = await UserService.resetPassword(code, newPassword);
            setMessage(response.message || 'Password reset successfully.');
            navigate('/login'); // Chuyển hướng sang trang đăng nhập sau khi thành công
        } catch (error) {
            setMessage(error.message);
        }
    };

    return (
        <div>
            <h2>Reset Password</h2>
            {code ? (
                <form onSubmit={handleResetPassword}>
                    <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter your new password"
                        required
                    />
                    <button type="submit">Reset Password</button>
                </form>
            ) : (
                <p>Verification code is missing. Please go back and request a new one.</p>
            )}
            {message && <p>{message}</p>}
        </div>
    );
}

export default ResetPassword;
