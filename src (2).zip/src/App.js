import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginPage from './components/auth/LoginPage';
import Header from './components/common/Header';
import SpotifyWebPlayer from './components/page/SpotifyWebPlayer';
import AudioPlayerPage from './components/userspage/AudioPlayerPage';
import RegisterPage from './components/userspage/RegisterPage';
import ForgotPassword from './components/userspage/ForgotPassword';
import ResetPassword from './components/userspage/ResetPassword';


function App() {
    return (
        <BrowserRouter>
            {/* <Header setSongdetail={setSongdetail}/> */}
            <div className="App">
                <div className="content">
                    <Routes>
                        <Route exact path="/" element={<LoginPage />} />
                        <Route path="/register" element={<RegisterPage />} />
                        <Route exact path="/profile" element={<SpotifyWebPlayer />} />
                        <Route path="/song/:songId" element={<AudioPlayerPage />} />
                        
                        {/* Thêm các tuyến đường cho quên mật khẩu và đặt lại mật khẩu */}
                        <Route path="/forgot-password" element={<ForgotPassword />} />
                        <Route path="/reset-password" element={<ResetPassword />} />
                    </Routes>
                </div>
            </div>
        </BrowserRouter>
    );
}

export default App;
